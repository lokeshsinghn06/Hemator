export const environment = {
    production :false,
    firebaseConfig : {
        apiKey: "AIzaSyDrHuVUKRXf4jdjzD75aiP7IFbATAhcg-I",
        authDomain: "hema-tor.firebaseapp.com",
        projectId: "hema-tor",
        storageBucket: "hema-tor.appspot.com",
        messagingSenderId: "903526696557",
        appId: "1:903526696557:web:51e12575c6a7ec5138e164"
      }
};
