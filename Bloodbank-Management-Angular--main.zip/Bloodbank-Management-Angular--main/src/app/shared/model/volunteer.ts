export interface Volunteer {
    volunteer_name :string;
    mobile :string;
    volunteer_id:string;
    gender : string;
    blood : string;
    age : string;
    date : Date
}
