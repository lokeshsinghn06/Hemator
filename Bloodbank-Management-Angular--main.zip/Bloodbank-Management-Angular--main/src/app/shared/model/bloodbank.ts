export interface bank{
    id:string;
    name:string;
    mobile:number;
    blood:string;
    email:string
} 
   
